import requests
import os
def send_html_message(to_email,subject,html):
    return requests.post(
        "https://api.mailgun.net/v3/stage.clipse.ai/messages",
        auth=("api", "key-ab3c394b8f5f60bc26dcc1c01673f096"),
        data={"from": "Clipse <updates@clipse.ai>",
              "to": to_email,
              "subject": subject,
              "html": html})

def send_text_message(to_email,subject,text):
    return requests.post(
        "https://api.mailgun.net/v3/stage.clipse.ai/messages",
        auth=("api", "key-ab3c394b8f5f60bc26dcc1c01673f096"),
        data={"from": "Clipse <updates@clipse.ai>",
              "to": to_email,
              "subject": subject,
              "text": text})


def send_html_message_with_attachments(to_email,subject,html,attachments):
    files = []
    for filepath in attachments:
      filename = os.path.split(filepath)[-1]
      val = ("attachment", (filename, open(filepath,"rb").read()))
      files.append(val)
    print files

    return requests.post(
        "https://api.mailgun.net/v3/stage.clipse.ai/messages",
        auth=("api", "key-ab3c394b8f5f60bc26dcc1c01673f096"),

        files =  files,

        
        data={"from": "Clipse <updates@clipse.ai>",
              "to": to_email,
              "subject": subject,
              "html": html
               })

    
              
