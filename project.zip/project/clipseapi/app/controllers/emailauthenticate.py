from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
#from flask_login import LoginManager, UserMixin, login_user, logout_user
import flask
import requests
import json
#from flask import logout_user

from flask_jwt import JWT, jwt_required, current_identity
from werkzeug.security import safe_str_cmp

#app = Flask(__name__)
val= getattr(g,'_app',None)

app = val.app

def authenticate(username, password):
	print "thgjhjkhklj"
    #user = username_table.get(username, None)
    #if user and safe_str_cmp(user.password.encode('utf-8'), password.encode('utf-8')):
        #return user
	return json.dumps({"test":"jhk"})


def identity(payload):
    #user_id = payload['identity']
    #return userid_table.get(user_id, None)
	return json.dumps({"iden":"jhk"})

jwt = JWT(app, authenticate, identity)

@app.route("/generate_token")
def get_token():
	payload = {'username':'pawan','email': 'test@yahoo.com'}
	print "kjjk"
	return jwt.encode(
            payload,
            app.config.get('SECRET_KEY'),
            algorithm='HS256'
        )

print jwt
print "kjhgfhj"
print dir(jwt)
@app.route('/protected')
@jwt_required()
def protected():
    return '%s' % current_identity
