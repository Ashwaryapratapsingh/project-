
from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
from  oauth import OAuthSignIn
#from flask_login import LoginManager, UserMixin, login_user, logout_user

#from flask import logout_user

val= getattr(g,'_app',None)

app = val.app

@app.route('/authorize/<provider>')
def oauth_authorize(provider):
    if not current_user.is_anonymous:
        ret = {"status":200, "message": "c"}
        return json.dumps(ret)
    oauth = OAuthSignIn.get_provider(provider)
    return oauth.authorize()


@app.route('/callback/<provider>')
def oauth_callback(provider):
    if not current_user.is_anonymous:
        return redirect(url_for('index'))
    oauth = OAuthSignIn.get_provider(provider)
    data = oauth.callback()
    print data, provider
    social_id = data[0]
    username = data[1]
    email = data[2]
    if social_id is None:
        ret = {"status":500, "message": "Authentication failed"}
        return json.dumps(ret)
    '''
    user = User.query.filter_by(social_id=social_id).first()
    if not user:
        user = User(social_id=social_id, nickname=username)
        db.session.add(user)
        db.session.commit()
    
    login_user(user, True)
    '''
    ret = {"status":200, "message": "User logged in successfully"}
    return json.dumps(ret)


