
from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
#from flask_login import LoginManager, UserMixin, login_user, logout_user
import flask
import requests
#from flask import logout_user

val= getattr(g,'_app',None)

app = val.app

@app.route('/sociallogin')
def fb_index():
    return render_template('social.html')


@app.route('/logout')
def logout():
    logout_user()
    if flask.session.has_key('credentials'):
        flask.session.pop('credentials')
    ret = {"status":200, "message": "User logged out successfully"}
    return json.dumps(ret)

'''

json.dumps(a). ----convert dict a to string 
eg:
>>> a = {"email":"kkkk@ya.com"}
>>> t =  json.dumps(a)
>>> t
'{"email": "kkkk@ya.com"}'

json.loads(t)--converts the string back to json
>>> f =  json.loads(t)
>>> f
{u'email': u'kkkk@ya.com'}
'''
@app.route('/testget')
def test():
    url = "https://www.qikwell.com/api/v2/clinics/get_clinics"
    data = {"chain_id":"00166132-8784-11e4-80bf-22000b021ea7","email":"hitechpundir@yahoo.com"}
    headers = {}
    response = requests.request("GET", url, headers=headers, params=data)
    
    return json.dumps(response.text)

@app.route('/testpost',methods = ['POST'])
def testpost():
	url = "http://yeshu.clipse.ai:5000/signuser"
	payload = "{\"email\":\"yeshu.clipse@gmail.com\"}"
	headers = {}    

	response = requests.request("POST", url, headers=headers, data=payload)
	return json.dumps(response.text)




