from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
#from flask_login import LoginManager, UserMixin, login_user, logout_user
import flask
import requests
import json
#from flask import logout_user

val= getattr(g,'_app',None)

app = val.app



@app.route('/signuser', methods = ['POST'])
def sign_user():    
    try:
		###capture data from ui

		mydict = json.loads(request.data)

		email = mydict["email"]
		print email
		#####send data to erlang
		
		url = app.config["ERLANG_SERVER"] +"/signup"
		print url
		data = {"email": email, "domain": ""}
		data = json.dumps(data)
		headers = {}
		response = requests.request("POST", url, headers=headers, data=data)
		return_value = json.loads(response.text)
		if return_value["success"] == "true":
			ret = {"success":"true","message": "signup successful"}
			return json.dumps(ret)
		else:
			ret = {"success":"false","message":str(e)}
        	return json.dumps(ret)

		
		#####        
		
    except Exception,e:
        ret = {"success":"false","message":str(e)}
        return json.dumps(ret)


@app.route('/email_registered',methods = ['POST'])
def email_exists():    
    try:
		###capture data from ui

		mydict = json.loads(request.data)

		email = mydict["email"]
		print email
		#####send data to erlang
		
		url = app.config["ERLANG_SERVER"] +"/is-registered/" + email
		print url
		data = {}
		data = json.dumps(data)
		headers = {}		
		response = requests.request("GET", url, headers=headers, params=data)
		return_value = json.loads(response.text)
		if return_value["success"] == "true":
			ret = {"success":"true","message": "email already exists"}
			return json.dumps(ret)
		else:
			ret = {"success":"false","message": "email does not exist"}
			return json.dumps(ret)
		
		
    except Exception,e:
        ret = {"success":"false","message":str(e)}
        return json.dumps(ret)


