
from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from icalendar import Calendar, Event
from pyicloud import PyiCloudService
from pyexchange import Exchange2010Service, ExchangeNTLMAuthConnection
import urllib
import flask
from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

from rauth.service import OAuth2Service

from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import OAuth2WebServerFlow
import httplib2
from datetime import datetime
#from flask_login import LoginManager, UserMixin, login_user, logout_user

#from flask import logout_user

val= getattr(g,'_app',None)

app = val.app



# Google calender events application
@app.route('/google/events')
def google_events():
  if 'credentials' not in flask.session:
    return flask.redirect(flask.url_for('oauth2callback'))
  credentials = client.OAuth2Credentials.from_json(flask.session['credentials'])
  if credentials.access_token_expired:
    return flask.redirect(flask.url_for('oauth2callback'))
  else:
    #http_auth = credentials.authorize(httplib2.Http())
    #drive = discovery.build('drive', 'v2', http_auth)
    #files = drive.files().list().execute()
    ######################################
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('calendar', 'v3', http=http)

    now = datetime.utcnow().isoformat() + 'Z' # 'Z' indicates UTC time
    print('Getting the upcoming 10 events')
    eventsResult = service.events().list(
        calendarId='primary', timeMin=now, maxResults=10, singleEvents=True,
        orderBy='startTime').execute()
    events = eventsResult.get('items', [])
    return json.dumps(events)






# Outlook calendar application
outlook_scopes = [ 'openid', 
           'https://outlook.office.com/mail.read',
           'https://outlook.office.com/calendars.read' ]

# Client ID and secret
outlook_client_id = 'b14ddc16-48f9-4a9c-bd76-14c4a9a23c7f'
outlook_client_secret = 'nRrNirwiTh37onokM0bkaNG'

# Constant strings for OAuth2 flow
# The OAuth authority
authority = 'https://login.microsoftonline.com'

# The authorize URL that initiates the OAuth2 client credential flow for admin consent
authorize_url = '{0}{1}'.format(authority, '/common/oauth2/v2.0/authorize?{0}')

# The token issuing endpoint
token_url = '{0}{1}'.format(authority, '/common/oauth2/v2.0/token')

# The scopes required by the app
@app.route("/login/outlook")
def outlook_login():
  #redirect_uri = request.build_absolute_uri(reverse('tutorial:gettoken'))
  redirect_uri=flask.url_for('get_access_token')
  sign_in_url = get_signin_url(redirect_uri)
  return render_template_string('<a href="' + sign_in_url +'">Click here to sign in and view your mail</a>')


def get_signin_url(redirect_uri):
  # Build the query parameters for the signin url
  params = { 'client_id': outlook_client_id,
             'redirect_uri': redirect_uri,
             'response_type': 'code',
             'scope': ' '.join(str(i) for i in outlook_scopes)
            }
            
  signin_url = authorize_url.format(urlencode(params))
  
  return signin_url

def get_token_from_refresh_token(refresh_token, redirect_uri):
  # Build the post form for the token request
  post_data = { 'grant_type': 'refresh_token',
                'refresh_token': refresh_token,
                'redirect_uri': redirect_uri,
                'scope': ' '.join(str(i) for i in scopes),
                'client_id': outlook_client_id,
                'client_secret': outlook_client_secret
              }
              
  r = requests.post(token_url, data = post_data)
  
  try:
    return r.json()
  except:
    return 'Error retrieving token: {0} - {1}'.format(r.status_code, r.text)

@app.route("/outlook")
def get_access_token(redirect_uri):
  current_token = request.session['access_token']
  expiration = request.session['token_expires']
  now = int(time.time())
  if (current_token and now < expiration):
    #Token still valid
    return current_token
  else:
    #Token expired
    refresh_token = request.session['refresh_token']
    new_tokens = get_token_from_refresh_token(refresh_token, redirect_uri)

    #Update session
    # expires_in is in seconds
    # Get current timestamp (seconds since Unix Epoch) and
    # add expires_in to get expiration time
    # Subtract 5 minutes to allow for clock differences
    expiration = int(time.time()) + new_tokens['expires_in'] - 300
    
    # Save the token in the session
    request.session['access_token'] = new_tokens['access_token']
    request.session['refresh_token'] = new_tokens['refresh_token']
    request.session['token_expires'] = expiration

    return new_tokens['access_token']

def get_my_events(access_token, user_email):
  get_events_url = outlook_api_endpoint.format('/Me/Events')

  # Use OData query parameters to control the results
  #  - Only first 10 results returned
  #  - Only return the Subject, Start, and End fields
  #  - Sort the results by the Start field in ascending order
  query_parameters = {'$top': '10',
                      '$select': 'Subject,Start,End',
                      '$orderby': 'Start/DateTime ASC'}

  r = make_api_call('GET', get_events_url, access_token, user_email, parameters = query_parameters)

  if (r.status_code == requests.codes.ok):
    return r.json()
  else:
    return "{0}: {1}".format(r.status_code, r.text)

@app.route('/outlook/events')
def events():
  access_token = get_access_token(request, request.build_absolute_uri(reverse('tutorial:gettoken')))
  user_email = request.session['user_email']
  # If there is no token in the session, redirect to home
  if not access_token:
    return HttpResponseRedirect(reverse('tutorial:home'))
  else:
    events = get_my_events(access_token, user_email)
    context = { 'events': events['value'] }
    return render(request, 'tutorial/events.html', context)






##################################

'''
# Outlook calendar events
URL = u'https://outlook.office365.com/EWS/Exchange.asmx'
USERNAME = u'yeshu.singh26@gmail.com'
PASSWORD = u"ashwarya00100728"

# Set up the connection to Exchange
connection = ExchangeNTLMAuthConnection(url=URL,
                                        username=USERNAME,
                                        password=PASSWORD)

service = Exchange2010Service(connection)
print dir(service)
print dir(service.calendar)
print type(service.calendar)
a = service.calendar()
print dir(a)
print "hhhhhhhhhhhh"
print a.list_events(start=timezone("US/Eastern").localize(datetime(2014, 10, 1, 11, 0, 0)),
    end=timezone("US/Eastern").localize(datetime(2014, 10, 29, 11, 0, 0)),
    details=True
)
'''
'''
for event in service.calendar_list.events:
    print "{start} {stop} - {subject}".format(
        start=event.start,
        stop=event.end,
        subject=event.subject
    )
'''

###############################













'''
# Icalendar event application
api = PyiCloudService('yeshu.singh26@gmail.com', 'Ashwarya28')
#api.calendar.get_event_detail('CALENDAR', 'EVENT_ID')

#api.calendar.events()


#api.calendar.events()[0].keys()  
 
from_dt = datetime(2017, 4, 30)
to_dt = datetime(2017, 5, 31)
#print api.calendar.events(from_dt, to_dt)[0].keys() 
print api.calendar.events(from_dt, to_dt)
'''



# Facebook user events application
@app.route('/facebook/events')
def facebook_events():
    
    url_events = "https://graph.facebook.com/" + session["facebook_id"] + "/events?access_token=" + session["facebook_token"]
    print url_events
    val = urllib.urlopen(url_events)
    
    
    return json.dumps(val.read())
