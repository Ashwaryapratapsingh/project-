
from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

from rauth.service import OAuth2Service

from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import OAuth2WebServerFlow
#from flask_login import LoginManager, UserMixin, login_user, logout_user
import httplib2

#from flask import logout_user
import flask
val= getattr(g,'_app',None)

app = val.app



# Google contacts application
@app.route('/google/contacts')
def google_contacts():
  if 'credentials' not in flask.session:
    return flask.redirect(flask.url_for('oauth2callback'))
  credentials = client.OAuth2Credentials.from_json(flask.session['credentials'])
  if credentials.access_token_expired:
    return flask.redirect(flask.url_for('oauth2callback'))
  else:    
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('people', 'v1', http=http, discoveryServiceUrl='https://people.googleapis.com/$discovery/rest')

    print('List 10 connection names')
    results = service.people().connections().list(resourceName='people/me',requestMask_includeField='person.email_addresses,person.names' ).execute()
    connections = results.get('connections', [])    
    return json.dumps(connections)


@app.route('/oauth2callback')
def oauth2callback():
    #redirect_url = flask.url_for('oauth2callback', _external = True) + '?' + request.query_string
    
   flow = client.flow_from_clientsecrets(
       'client_secret.json',
       scope="https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/contacts.readonly",
       redirect_uri=flask.url_for('oauth2callback', _external=True)
       )
   if 'code' not in flask.request.args:
    auth_uri = flow.step1_get_authorize_url()
    return flask.redirect(auth_uri)
   else:
    auth_code = flask.request.args.get('code')
    credentials = flow.step2_exchange(auth_code)
    flask.session['credentials'] = credentials.to_json()
    
    return flask.redirect(flask.url_for('google_events'))
    


