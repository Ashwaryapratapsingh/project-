#/socifrom __future__ import print_function

from flask import Flask
from flask import g,Flask, redirect, url_for, render_template, flash, json, render_template_string
from flask import request, redirect, session, Blueprint
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
#from flask_login import LoginManager, UserMixin, login_user, logout_user
import flask
import requests
import json



from flask import g,current_app
from flask import Flask, redirect, url_for, render_template, flash, json, render_template_string

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user,\
    current_user
from oauth import OAuthSignIn
import requests
import pickle
import string
import csv

from flask import request, redirect, session

import base64



from utils import send_html_message, send_html_message_with_attachments
from datetime import date
from flask_user import login_required,roles_required
from werkzeug import secure_filename
import os
from math import ceil
from flask_paginate import Pagination
import datetime
import facebook
import icalendar
from icalendar import Calendar, Event
from pyicloud import PyiCloudService
#import datetime
from datetime import datetime
from pyexchange import Exchange2010Service, ExchangeNTLMAuthConnection
###
import json

import flask
import httplib2

from apiclient import discovery
from oauth2client import client
##

from urllib import  urlencode
import base64
import json
import time
from pytz import timezone

import atom.data
import gdata.data
import gdata.contacts.client
import gdata.contacts.data

import httplib2
import os
from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage



from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import OAuth2WebServerFlow

import urllib

import gdata.gauth
import atom.http_core
import gdata.contacts.service


import atom.data
import gdata.data
import gdata.contacts.client
import gdata.contacts.data
import atom.http_core



#from flask_user import login_required

#html_content = welcome_email.html_content

#print html_content
app = Flask(__name__)

app.config.from_object('config')

ctx= app.app_context()
ctx.push()
g._app = ctx
#ctx.push()
'''
with app.app_context():
    # within this block, current_app points to app.
    #print current_app.name
    g._app = 
'''

from controllers import sociallogin,auth,contact,event,login, emailauthenticate
#app = Flask(__name__, template_folder='views/'templates')
'''
app.config['WTF_SCRF_ENABLED'] = True
app.config['SECRET_KEY'] = 'top secret!'



#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:p@ssword@localhost/clipse'

app.debug = True

app.config['SQLALCHEMY_ECHO'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:ashwarya@localhost/clipse'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


app.config['OAUTH_CREDENTIALS'] = {
    'facebook': {
        'id': '136430806467361',
        'secret': '7ae9e482bf9e4e5ce357718e9b179a83'
    },
    'twitter': {
        'id': 'YrvBfrMpH7xcL4Xi8bJ38wtOv',
        'secret': 'MgpqDQmgHKEwMADMtNit42no0A6YleYffiI3hQelypbdTxBLpS'
    },
    'google': {
        'id' : '153230217988-j17rtl2ov5t5ph8v3vlc55a2prthr0bj.apps.googleusercontent.com',
        'secret' : '9JVg308NDJvi1bTymsoGVChS'
    },
    'linkedin': {
        'id' : '78f11g0huosy86',
        'secret' : 'HbELzX2t8WRiBlWo'
    }

}
'''





db = SQLAlchemy(app)
lm = LoginManager(app)
#lm.login_view = '/admin/login'
 





@app.route("/test")
def testme():
    return "ok"





db.create_all()

