WTF_SCRF_ENABLED = True
SECRET_KEY = 'you-will-never-guess'
SQLALCHEMY_ECHO = False
SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:mysqlRoot@localhost/clipse'
SQLALCHEMY_TRACK_MODIFICATIONS = False
OAUTH_CREDENTIALS = {
    'facebook': {
        'id': '136430806467361',
        'secret': '7ae9e482bf9e4e5ce357718e9b179a83'
    },
    'twitter': {
        'id': 'YrvBfrMpH7xcL4Xi8bJ38wtOv',
        'secret': 'MgpqDQmgHKEwMADMtNit42no0A6YleYffiI3hQelypbdTxBLpS'
    },
    'google': {
        'id' : '153230217988-j17rtl2ov5t5ph8v3vlc55a2prthr0bj.apps.googleusercontent.com',
        'secret' : '9JVg308NDJvi1bTymsoGVChS'
    },
    'linkedin': {
        'id' : '78f11g0huosy86',
        'secret' : 'HbELzX2t8WRiBlWo'
    }

}
ERLANG_SERVER = "http://clipse.erlang.ai"
